﻿/*
    This file is part of the VeriFactu (R) project.
    Copyright (c) 2024-2025 Irene Solutions SL
    Authors: Irene Solutions SL.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation with the addition of the
    following permission added to Section 15 as permitted in Section 7(a):
    FOR ANY PART OF THE COVERED WORK IN WHICH THE COPYRIGHT IS OWNED BY
    IRENE SOLUTIONS SL. IRENE SOLUTIONS SL DISCLAIMS THE WARRANTY OF NON INFRINGEMENT
    OF THIRD PARTY RIGHTS
    
    This program is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU Affero General Public License for more details.
    You should have received a copy of the GNU Affero General Public License
    along with this program; if not, see http://www.gnu.org/licenses or write to
    the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA, 02110-1301 USA, or download the license from the following URL:
        http://www.irenesolutions.com/terms-of-use.pdf
    
    The interactive user interfaces in modified source and object code versions
    of this program must display Appropriate Legal Notices, as required under
    Section 5 of the GNU Affero General Public License.
    
    You can be released from the requirements of the license by purchasing
    a commercial license. Buying such a license is mandatory as soon as you
    develop commercial activities involving the VeriFactu software without
    disclosing the source code of your own applications.
    These activities include: offering paid services to customers as an ASP,
    serving VeriFactu XML data on the fly in a web application, shipping VeriFactu
    with a closed source product.
    
    For more information, please contact Irene Solutions SL. at this
    address: info@irenesolutions.com
 */

using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using VeriFactu.Common.Exceptions;
using VeriFactu.Config;
using VeriFactu.Net;
using VeriFactu.Xml.Factu;
using VeriFactu.NoVeriFactu.Signature;

namespace VeriFactu.Business.Operations
{

    /// <summary>
    /// Representa una acción de alta o anulación de registro
    /// en todo lo referente a su gestión contable en la 
    /// cadena de bloques.
    /// </summary>
    public class InvoiceActionPost : InvoiceActionMessage
    {

        #region Variables Privadas de Instancia

        /// <summary>
        /// Bloqueo para thread safe.
        /// </summary>
        private readonly object _Locker = new object();

        #endregion

        #region Construtores de Instancia

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="invoice">Instancia de factura de entrada en el sistema.</param>
        public InvoiceActionPost(Invoice invoice) : base(invoice)
        {

            BlockchainManager = Blockchain.Blockchain.Get(Invoice.SellerID);

        }

        #endregion

        #region Métodos Privados de Instancia

        /// <summary>
        /// Contabiliza una entrada.
        /// <para> 1. Incluye el registro en la cadena de bloques.</para>
        /// <para> 2. Recalcula Xml con la info Blockchain actualizada.</para>
        /// <para> 3. Guarda el registro en disco en el el directorio de registros emitidos.</para>
        /// <para> 4. Establece Posted = true.</para>
        /// </summary>
        /// <param name="certificate">Certificado para la firma.</param>
        internal virtual void Post(X509Certificate2 certificate)
        {

            // Añadimos el registro de alta (1)
            BlockchainManager.Add(Registro);

            // Actualizamos datos (2,3,4)
            SaveBlockchainChanges(certificate);

        }

        /// <summary>
        /// Actualiza los datos tras la incorporación del registro
        /// a la cadena de bloques.
        /// <para> 1. Recalcula Xml con la info Blockchain actualizada.</para>
        /// <para> 2. Guarda el registro en disco en el el directorio de registros emitidos.</para>
        /// <para> 3. Establece Posted = true.</para>
        /// </summary>
        /// <param name="certificate">Certificado para la firma.</param>
        /// <exception cref="InvalidOperationException"></exception>
        internal virtual void SaveBlockchainChanges(X509Certificate2 certificate)
        {

            if (Registro.BlockchainLinkID == 0)
                throw new InvalidOperationException($"El registro {Registro}" +
                    $" no está incluido en la cadena de bloques.");

            if (Posted)
                throw new InvalidOperationException($"La operación {this}" +
                    $" ya está contabilizada.");

            if (!string.IsNullOrEmpty(Settings.Current.IsNotVerifactu))
            {

                // En NO VERI*FACTU almacenamos el registro firmado.
                var signer = new NoVeriFactu.Signature.Signer(certificate);

                Xml = signer.Sign(Registro);

            }
            else
            {

                // En VERI*FACTU regeneramos el Xml con la información
                // de blockchain actualizada.
                Xml = GetXml();

            }

            // Guardamos el xml
            File.WriteAllBytes(InvoiceFilePath, Xml);

            // Marcamos como contabilizado
            Posted = true;

        }

        /// <summary>
        /// Deshace cambios de guardado de documente eliminando
        /// el elemento de la cadena de bloques (si DisableBlockchainDelete = false)
        /// y marcando los archivos relacionados como erróneos.
        /// </summary>
        protected void ClearPost()
        {

            Exception undoException = null;

            lock (_Locker)
            {

                try
                {

                    // Elimino eslabón de la cadena de bloques
                    if(!Settings.Current.DisableBlockchainDelete)
                        BlockchainManager.Delete(Registro);

                    if (File.Exists(InvoiceEntryFilePath))
                        File.Move(InvoiceEntryFilePath, GetErrorInvoiceEntryFilePath());

                    if (File.Exists(InvoiceFilePath))
                        File.Move(InvoiceFilePath, GetErrorInvoiceFilePath());

                    Posted = false;

                }
                catch (Exception ex)
                {

                    undoException = ex;

                }

            }

            if (undoException != null)
                throw new ClearPostException(undoException);

        }

        /// <summary>
        /// Ejecuta la contabilización del registro.
        /// </summary>
        /// <param name="certificate">Certificado para la firma.</param>
        /// <returns>Si todo funciona correctamente devuelve null.
        /// En caso contrario devuelve una excepción con el error.</returns>
        internal void ExecutePost(X509Certificate2 certificate = null)
        {

            // Obtengo el certificado a utilizar.
            var cert = certificate ?? Wsd.GetCheckedCertificate();

            if (cert == null)
                throw new Exception("Existe algún problema con el certificado.");

            Exception postException = null;

            lock (_Locker)
            {

                try
                {

                    Post(cert);                   

                }
                catch (Exception ex)
                {

                    postException = ex;

                }

            }

            if (postException != null)
                throw new PostException(postException);

        }

        #endregion

        #region Propiedades Públicas de Instancia

        /// <summary>
        /// Gestor de cadena de bloques para el registro.
        /// </summary>
        public Blockchain.Blockchain BlockchainManager { get; private set; }

        #endregion

        #region Métodos Públicos de Instancia

        /// <summary>
        /// Contabiliza y envía a la AEAT el registro.
        /// </summary>
        /// <param name="certificate">Certificado para la petición.</param>
        /// <exception cref="InvalidOperationException">Si ya se ha guardado con anterioridad.</exception>
        /// <exception cref="Exception">Si surge error en el envío.</exception>
        public void Save(X509Certificate2 certificate = null)
        {

            if (IsSaved)
                throw new InvalidOperationException("El objeto InvoiceEntry sólo" +
                    " puede llamar al método Save() una vez.");

            // Determinamos una única vez el certificado a utilizar.
            var cert = certificate ?? Wsd.GetCheckedCertificate();

            if (cert == null)
                throw new Exception("Existe algún problema con el certificado.");

            Exception sendException = null;

            ExecutePost(cert);

            // En NO VERI*FACTU el registro se almacena localmente
            // y no se remite a la AEAT.
            if (!string.IsNullOrEmpty(Settings.Current.IsNotVerifactu))
            {

                IsSaved = true;
                return;

            }

            try
            {
                ExecuteSend(cert);
                ProcessResponse();
            }
            catch (Exception ex)
            {

                sendException = ex;
                ClearPost();

            }

            if (string.IsNullOrEmpty(CSV) || sendException != null)
                if(sendException == null)
                    ClearPost();

            if (sendException != null)
                throw new SendException(sendException);

            IsSaved = true;

        }

        #endregion

    }
}